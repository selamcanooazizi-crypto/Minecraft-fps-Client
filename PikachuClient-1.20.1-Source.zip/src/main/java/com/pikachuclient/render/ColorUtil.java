package com.pikachuclient.render;

import net.minecraft.util.math.MathHelper;

public final class ColorUtil {
    public static final String[] NAMES = {"Yellow", "Blue", "White", "Red", "Green", "Rainbow"};

    /** @return {r, g, b, a} in 0..1. phase (0..1) offsets the rainbow hue. */
    public static float[] rgba(String mode, float alpha, float phase) {
        switch (mode) {
            case "Blue": return new float[]{0.30f, 0.72f, 1f, alpha};
            case "White": return new float[]{1f, 1f, 1f, alpha};
            case "Red": return new float[]{1f, 0.25f, 0.25f, alpha};
            case "Green": return new float[]{0.3f, 1f, 0.4f, alpha};
            case "Rainbow": {
                float h = ((System.currentTimeMillis() % 3000L) / 3000f + phase) % 1f;
                int rgb = MathHelper.hsvToRgb(h, 1f, 1f);
                return new float[]{(rgb >> 16 & 255) / 255f, (rgb >> 8 & 255) / 255f, (rgb & 255) / 255f, alpha};
            }
            default: return new float[]{1f, 0.85f, 0.23f, alpha};
        }
    }

    private ColorUtil() {}
}
