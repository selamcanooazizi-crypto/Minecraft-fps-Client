package com.pikachuclient.render;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws lines into a RenderLayer.getLines() consumer (position-color-normal format). */
public final class LineRenderer {
    public static void line(VertexConsumer vc, MatrixStack.Entry e,
                            float x1, float y1, float z1, float x2, float y2, float z2, float[] c) {
        float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        dx /= len; dy /= len; dz /= len;
        Matrix4f pos = e.getPositionMatrix();
        Matrix3f nrm = e.getNormalMatrix();
        vc.vertex(pos, x1, y1, z1).color(c[0], c[1], c[2], c[3]).normal(nrm, dx, dy, dz).next();
        vc.vertex(pos, x2, y2, z2).color(c[0], c[1], c[2], c[3]).normal(nrm, dx, dy, dz).next();
    }

    public static void box(VertexConsumer vc, MatrixStack.Entry e,
                           float x1, float y1, float z1, float x2, float y2, float z2, float[] c) {
        line(vc, e, x1, y1, z1, x2, y1, z1, c); line(vc, e, x1, y1, z2, x2, y1, z2, c);
        line(vc, e, x1, y2, z1, x2, y2, z1, c); line(vc, e, x1, y2, z2, x2, y2, z2, c);
        line(vc, e, x1, y1, z1, x1, y2, z1, c); line(vc, e, x2, y1, z1, x2, y2, z1, c);
        line(vc, e, x1, y1, z2, x1, y2, z2, c); line(vc, e, x2, y1, z2, x2, y2, z2, c);
        line(vc, e, x1, y1, z1, x1, y1, z2, c); line(vc, e, x2, y1, z1, x2, y1, z2, c);
        line(vc, e, x1, y2, z1, x1, y2, z2, c); line(vc, e, x2, y2, z1, x2, y2, z2, c);
    }

    private LineRenderer() {}
}
