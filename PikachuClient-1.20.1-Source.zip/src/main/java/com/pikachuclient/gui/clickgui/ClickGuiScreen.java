package com.pikachuclient.gui.clickgui;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.ModeSetting;
import com.pikachuclient.module.setting.NumberSetting;
import com.pikachuclient.module.setting.Setting;
import com.pikachuclient.render.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.DoubleConsumer;

/**
 * Click GUI. Large rows so it works with touch (launchers map touch to mouse clicks).
 * Click a module = toggle, "..." = open its real settings. Drag on empty space (or mouse wheel) scrolls.
 */
public class ClickGuiScreen extends Screen {
    private static final int SIDE_W = 82, ROW_H = 24, SET_H = 20, HEADER_H = 28;
    private static Category selected;

    private Module expanded, listening, listenedBefore;
    private double scroll;
    private int contentHeight;
    private int cx, cy, cw, ch;
    private final List<Region> regions = new ArrayList<>();
    private Region dragging;

    private static final class Region {
        final int x1, y1, x2, y2;
        final boolean content;
        final Runnable click;
        final DoubleConsumer drag;

        Region(int x1, int y1, int x2, int y2, boolean content, Runnable click, DoubleConsumer drag) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.content = content; this.click = click; this.drag = drag;
        }

        boolean contains(double mx, double my) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }
    }

    public ClickGuiScreen() {
        super(Text.literal("Pikachu Client"));
        List<Category> cats = PikachuClient.modules().categories();
        if (selected == null || !cats.contains(selected)) selected = cats.get(0);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        boolean ok = PikachuClient.config().save();
        PikachuClient.notifications().push(ok ? "Configuration saved" : "Could not save configuration");
    }

    private boolean visible(int y, int h) { return y + h > cy && y < cy + ch; }

    private String keyName(int key) {
        if (key <= 0) return "None";
        return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        regions.clear();
        ctx.fill(0, 0, width, height, 0x80000000);

        int pw = Math.min(width - 12, 440), ph = Math.min(height - 12, 270);
        int px = (width - pw) / 2, py = (height - ph) / 2;
        ctx.fill(px, py, px + pw, py + ph, Theme.BG);
        ctx.fill(px, py, px + pw, py + 2, Theme.ACCENT);
        ctx.drawText(textRenderer, "PIKACHU CLIENT", px + 10, py + 10, Theme.ACCENT, true);
        String hint = PikachuClient.guiKey().getBoundKeyLocalizedText().getString() + " = close";
        ctx.drawText(textRenderer, hint, px + pw - textRenderer.getWidth(hint) - 8, py + 10, Theme.DIM, false);

        // Sidebar
        ctx.fill(px, py + HEADER_H, px + SIDE_W, py + ph, Theme.PANEL);
        int sy = py + HEADER_H;
        for (Category c : PikachuClient.modules().categories()) {
            boolean sel = c == selected;
            boolean hover = mouseX >= px && mouseX < px + SIDE_W && mouseY >= sy && mouseY < sy + 26;
            if (sel) ctx.fill(px, sy, px + SIDE_W, sy + 26, Theme.ROW_ON);
            else if (hover) ctx.fill(px, sy, px + SIDE_W, sy + 26, Theme.ROW_HOVER);
            if (sel) ctx.fill(px, sy, px + 2, sy + 26, Theme.ACCENT);
            ctx.drawText(textRenderer, c.getLabel(), px + 10, sy + 9, sel ? Theme.ACCENT : Theme.TEXT, true);
            regions.add(new Region(px, sy, px + SIDE_W, sy + 26, false, () -> {
                selected = c; scroll = 0; expanded = null; listening = null;
            }, null));
            sy += 26;
        }

        // Content
        cx = px + SIDE_W + 8; cy = py + HEADER_H + 4; cw = pw - SIDE_W - 16; ch = ph - HEADER_H - 12;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - ch)));
        int y = cy - (int) scroll;
        ctx.enableScissor(cx, cy, cx + cw, cy + ch);
        for (Module m : PikachuClient.modules().byCategory(selected)) {
            y = drawModule(ctx, m, y, mouseX, mouseY);
        }
        contentHeight = y + (int) scroll - cy;
        ctx.disableScissor();
    }

    private int drawModule(DrawContext ctx, Module m, int y, int mouseX, int mouseY) {
        int rx2 = cx + cw;
        boolean on = m.isEnabled();
        if (visible(y, ROW_H)) {
            boolean hover = mouseX >= cx && mouseX < rx2 && mouseY >= Math.max(y, cy) && mouseY < Math.min(y + ROW_H, cy + ch);
            ctx.fill(cx, y, rx2, y + ROW_H, on ? Theme.ROW_ON : hover ? Theme.ROW_HOVER : Theme.ROW);
            if (on) ctx.fill(cx, y, cx + 2, y + ROW_H, Theme.ACCENT);
            ctx.drawText(textRenderer, m.getName(), cx + 8, y + 8, on ? Theme.ACCENT : Theme.TEXT, true);
            int gx = rx2 - ROW_H;
            ctx.drawText(textRenderer, "...", gx + 7, y + 8, expanded == m ? Theme.ACCENT : Theme.DIM, false);
            int pillX = gx - 26;
            ctx.fill(pillX, y + 8, pillX + 20, y + 16, on ? Theme.ACCENT : 0xFF555555);
            if (on) ctx.fill(pillX + 12, y + 9, pillX + 19, y + 15, 0xFFFFFFFF);
            else ctx.fill(pillX + 1, y + 9, pillX + 8, y + 15, 0xFFAAAAAA);
            regions.add(new Region(cx, y, gx, y + ROW_H, true, m::toggle, null));
            regions.add(new Region(gx, y, rx2, y + ROW_H, true, () -> expanded = expanded == m ? null : m, null));
        }
        y += ROW_H + 2;

        if (expanded == m) {
            if (visible(y, 16)) {
                ctx.drawText(textRenderer, textRenderer.trimToWidth(m.getDescription(), cw - 16), cx + 8, y + 4, Theme.DIM, false);
            }
            y += 16;
            for (Setting<?> s : m.getSettings()) y = drawSetting(ctx, s, y);

            if (visible(y, SET_H)) {
                ctx.fill(cx + 6, y, rx2, y + SET_H, Theme.SET_ROW);
                String t = "Keybind: " + keyName(m.getKey()) + (listening == m ? "  (press key, Backspace clears)" : "");
                ctx.drawText(textRenderer, textRenderer.trimToWidth(t, cw - 24), cx + 12, y + 6, listening == m ? Theme.ACCENT : Theme.TEXT, false);
                regions.add(new Region(cx + 6, y, rx2, y + SET_H, true, () -> listening = (listenedBefore == m) ? null : m, null));
            }
            y += SET_H + 1;
            if (visible(y, SET_H)) {
                ctx.fill(cx + 6, y, rx2, y + SET_H, Theme.SET_ROW);
                ctx.drawText(textRenderer, "Reset settings to default", cx + 12, y + 6, Theme.BLUE, false);
                regions.add(new Region(cx + 6, y, rx2, y + SET_H, true, m::resetSettings, null));
            }
            y += SET_H + 5;
        }
        return y;
    }

    private int drawSetting(DrawContext ctx, Setting<?> s, int y) {
        int rx2 = cx + cw;
        if (visible(y, SET_H)) {
            ctx.fill(cx + 6, y, rx2, y + SET_H, Theme.SET_ROW);
            if (s instanceof BooleanSetting b) {
                boolean v = b.getValue();
                ctx.drawText(textRenderer, b.getName(), cx + 12, y + 6, Theme.TEXT, false);
                String t = v ? "ON" : "OFF";
                ctx.drawText(textRenderer, t, rx2 - textRenderer.getWidth(t) - 8, y + 6, v ? Theme.ACCENT : Theme.DIM, false);
                regions.add(new Region(cx + 6, y, rx2, y + SET_H, true, b::toggle, null));
            } else if (s instanceof ModeSetting md) {
                ctx.drawText(textRenderer, md.getName(), cx + 12, y + 6, Theme.TEXT, false);
                String t = "< " + md.getValue() + " >";
                ctx.drawText(textRenderer, t, rx2 - textRenderer.getWidth(t) - 8, y + 6, Theme.ACCENT, false);
                regions.add(new Region(cx + 6, y, rx2, y + SET_H, true, md::cycle, null));
            } else if (s instanceof NumberSetting n) {
                String val = n.isInteger() ? String.valueOf(n.intValue()) : String.format(Locale.ROOT, "%.1f", n.getValue());
                ctx.drawText(textRenderer, n.getName(), cx + 12, y + 3, Theme.TEXT, false);
                ctx.drawText(textRenderer, val, rx2 - textRenderer.getWidth(val) - 8, y + 3, Theme.ACCENT, false);
                final int tx1 = cx + 12, tx2 = rx2 - 8;
                ctx.fill(tx1, y + SET_H - 6, tx2, y + SET_H - 3, 0xFF333333);
                ctx.fill(tx1, y + SET_H - 6, tx1 + (int) ((tx2 - tx1) * n.fraction()), y + SET_H - 3, Theme.ACCENT);
                regions.add(new Region(cx + 6, y, rx2, y + SET_H, true, null, mx -> {
                    double f = Math.max(0, Math.min(1, (mx - tx1) / (double) (tx2 - tx1)));
                    n.setValue(n.getMin() + f * (n.getMax() - n.getMin()));
                }));
            }
        }
        return y + SET_H + 1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            listenedBefore = listening;
            listening = null;
            for (int i = regions.size() - 1; i >= 0; i--) {
                Region r = regions.get(i);
                if (!r.contains(mx, my)) continue;
                if (r.content && (my < cy || my >= cy + ch)) continue;
                if (r.drag != null) { dragging = r; r.drag.accept(mx); }
                if (r.click != null) r.click.run();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { dragging.drag.accept(mx); return true; }
        if (mx >= cx && mx < cx + cw && my >= cy && my < cy + ch) { scroll -= dy; return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll -= amount * 20;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            Module m = listening;
            listening = null;
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) return true;
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) { m.setKey(-1); return true; }
            Module conflict = PikachuClient.modules().findByKey(keyCode, m);
            if (conflict != null) PikachuClient.notifications().push("Key already used by " + conflict.getName());
            else if (PikachuClient.guiKey().matchesKey(keyCode, scanCode)) PikachuClient.notifications().push("That key opens this GUI");
            else m.setKey(keyCode);
            return true;
        }
        if (PikachuClient.guiKey().matchesKey(keyCode, scanCode)) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
