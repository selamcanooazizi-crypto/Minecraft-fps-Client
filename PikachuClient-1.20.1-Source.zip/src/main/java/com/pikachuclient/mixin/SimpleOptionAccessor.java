package com.pikachuclient.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Lets Fullbright set gamma above the vanilla 0..1 validation range (client-side only). */
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor<T> {
    @Mutable
    @Accessor("value")
    void pikachu$setValue(T value);
}
