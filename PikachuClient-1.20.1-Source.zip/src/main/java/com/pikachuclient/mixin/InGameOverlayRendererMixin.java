package com.pikachuclient.mixin;

import com.pikachuclient.module.render.LowFireModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    @Unique private static double pikachu$shift;

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void pikachu$fireHead(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        pikachu$shift = 0;
        LowFireModule m = LowFireModule.instance;
        if (m == null || !m.isEnabled()) return;
        if (m.hide.getValue()) { ci.cancel(); return; }
        pikachu$shift = m.lowerBy.getValue();
        matrices.translate(0.0, -pikachu$shift, 0.0);
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"), require = 0)
    private static void pikachu$fireReturn(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        if (pikachu$shift != 0) {
            matrices.translate(0.0, pikachu$shift, 0.0);
            pikachu$shift = 0;
        }
    }
}
