package com.pikachuclient.mixin;

import com.pikachuclient.module.render.ViewModelModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void pikachu$vmHead(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        ViewModelModule.pushed = false;
        ViewModelModule vm = ViewModelModule.instance;
        if (vm == null || !vm.isEnabled() || !vm.appliesTo(hand)) return;
        matrices.push();
        ViewModelModule.pushed = true;
        vm.apply(matrices, hand, player);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void pikachu$vmReturn(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                  float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                  VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (ViewModelModule.pushed) {
            matrices.pop();
            ViewModelModule.pushed = false;
        }
    }
}
