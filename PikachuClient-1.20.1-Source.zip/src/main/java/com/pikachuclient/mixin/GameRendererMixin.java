package com.pikachuclient.mixin;

import com.pikachuclient.module.render.NoHurtCamModule;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void pikachu$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        NoHurtCamModule m = NoHurtCamModule.instance;
        if (m != null && m.isEnabled()) ci.cancel();
    }
}
