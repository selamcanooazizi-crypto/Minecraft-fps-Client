package com.pikachuclient.config;

import com.google.gson.*;
import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.ModuleManager;
import com.pikachuclient.module.hud.HudModule;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.function.Consumer;

/** Stores config in .minecraft/config/pikachuclient/ (config.json, hud.json, keybinds.json, profiles/). */
public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path dir = FabricLoader.getInstance().getConfigDir().resolve("pikachuclient");
    private final ModuleManager modules;

    public ConfigManager(ModuleManager modules) { this.modules = modules; }

    public Path getDir() { return dir; }

    public void load() {
        try { Files.createDirectories(dir.resolve("profiles")); }
        catch (IOException e) { PikachuClient.LOGGER.error("Cannot create config directory", e); return; }

        boolean recovered = false;

        recovered |= read("config.json", root -> {
            JsonObject mods = root.getAsJsonObject("modules");
            if (mods == null) return;
            for (Module m : modules.all()) {
                if (!mods.has(m.getId()) || !mods.get(m.getId()).isJsonObject()) continue;
                JsonObject o = mods.getAsJsonObject(m.getId());
                if (o.has("enabled") && o.get("enabled").isJsonPrimitive()) {
                    try { m.loadEnabledRaw(o.get("enabled").getAsBoolean()); } catch (Exception ignored) {}
                }
                if (o.has("settings") && o.get("settings").isJsonObject()) m.loadSettings(o.getAsJsonObject("settings"), false);
            }
        });

        recovered |= read("hud.json", root -> {
            JsonObject els = root.getAsJsonObject("elements");
            if (els == null) return;
            for (Module m : modules.all()) {
                if (m instanceof HudModule && els.has(m.getId()) && els.get(m.getId()).isJsonObject())
                    m.loadSettings(els.getAsJsonObject(m.getId()), true);
            }
        });

        recovered |= read("keybinds.json", root -> {
            JsonObject binds = root.getAsJsonObject("binds");
            if (binds == null) return;
            for (Module m : modules.all()) {
                if (binds.has(m.getId()) && binds.get(m.getId()).isJsonPrimitive()) {
                    try { m.setKey(binds.get(m.getId()).getAsInt()); } catch (Exception ignored) {}
                }
            }
        });

        if (recovered) PikachuClient.notifications().push("Invalid config recovered (defaults used)");
    }

    public boolean save() {
        try {
            Files.createDirectories(dir.resolve("profiles"));

            JsonObject cfg = new JsonObject();
            cfg.addProperty("version", 1);
            JsonObject mods = new JsonObject();
            JsonObject hud = new JsonObject();
            hud.addProperty("version", 1);
            JsonObject els = new JsonObject();
            JsonObject keys = new JsonObject();
            keys.addProperty("version", 1);
            JsonObject binds = new JsonObject();

            for (Module m : modules.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.add("settings", m.saveSettings(false));
                mods.add(m.getId(), o);
                if (m instanceof HudModule) els.add(m.getId(), m.saveSettings(true));
                if (m.getKey() > 0) binds.addProperty(m.getId(), m.getKey());
            }
            cfg.add("modules", mods);
            hud.add("elements", els);
            keys.add("binds", binds);

            write("config.json", cfg);
            write("hud.json", hud);
            write("keybinds.json", keys);
            return true;
        } catch (Exception e) {
            PikachuClient.LOGGER.error("Failed to save config", e);
            return false;
        }
    }

    /** @return true if the file existed but was invalid (it is moved to *.broken). */
    private boolean read(String name, Consumer<JsonObject> consumer) {
        Path p = dir.resolve(name);
        if (!Files.exists(p)) return false;
        try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            JsonElement el = JsonParser.parseReader(r);
            if (!el.isJsonObject()) throw new JsonParseException("Root is not an object");
            consumer.accept(el.getAsJsonObject());
            return false;
        } catch (Exception e) {
            PikachuClient.LOGGER.error("Invalid {}; backing up and using defaults", name, e);
            try { Files.move(p, dir.resolve(name + ".broken"), StandardCopyOption.REPLACE_EXISTING); } catch (IOException ignored) {}
            return true;
        }
    }

    private void write(String name, JsonObject obj) throws IOException {
        Path target = dir.resolve(name);
        Path tmp = dir.resolve(name + ".tmp");
        Files.writeString(tmp, GSON.toJson(obj), StandardCharsets.UTF_8);
        try {
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
