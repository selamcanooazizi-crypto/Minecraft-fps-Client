package com.pikachuclient.module.hud;

import com.pikachuclient.render.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class TextHudModule extends HudModule {
    private String[] cache;
    private int w, h;

    protected TextHudModule(String id, String name, String description, double defX, double defY) {
        super(id, name, description, defX, defY);
    }

    protected abstract String[] lines(MinecraftClient mc);

    @Override
    protected int[] size(MinecraftClient mc) {
        cache = lines(mc);
        if (cache == null || cache.length == 0) return null;
        int mw = 0;
        for (String l : cache) mw = Math.max(mw, mc.textRenderer.getWidth(l));
        w = mw + 10;
        h = cache.length * 10 + 5;
        return new int[]{w, h};
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc) {
        if (background.getValue()) ctx.fill(0, 0, w, h, bgColor());
        ctx.fill(0, 0, 2, h, Theme.ACCENT);
        for (int i = 0; i < cache.length; i++) {
            ctx.drawText(mc.textRenderer, cache[i], 6, 3 + i * 10, Theme.TEXT, true);
        }
    }
}
