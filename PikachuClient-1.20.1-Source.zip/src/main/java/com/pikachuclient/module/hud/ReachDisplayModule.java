package com.pikachuclient.module.hud;

import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Locale;

/**
 * Informational only: shows the distance from your eyes to the entity under your crosshair.
 * This is a client-side measurement; it does NOT change your real reach or hitboxes.
 */
public class ReachDisplayModule extends TextHudModule {
    private final NumberSetting decimals = add(new NumberSetting("Decimals", 2, 0, 3, 1, true));
    private double last = -1;
    private long lastTime;

    public ReachDisplayModule() {
        super("reach", "Reach Display", "Shows the aim distance to the targeted entity (client-side measurement).", 1, 22);
    }

    @Override
    protected String[] lines(MinecraftClient mc) {
        if (mc.player == null) return null;
        long now = System.currentTimeMillis();
        HitResult h = mc.crosshairTarget;
        if (h instanceof EntityHitResult e) {
            last = mc.player.getEyePos().distanceTo(e.getPos());
            lastTime = now;
        }
        if (last >= 0 && now - lastTime < 2000) {
            return new String[]{"Reach: " + String.format(Locale.ROOT, "%." + decimals.intValue() + "f", last)};
        }
        return new String[]{"Reach: -"};
    }
}
