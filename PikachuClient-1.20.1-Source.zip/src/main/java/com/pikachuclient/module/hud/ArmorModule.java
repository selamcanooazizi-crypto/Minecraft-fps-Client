package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Shows equipped armor with real durability percentages. */
public class ArmorModule extends HudModule {
    private final List<ItemStack> stacks = new ArrayList<>();

    public ArmorModule() {
        super("armor", "Armor Status", "Shows equipped armor and durability.", 99, 50);
    }

    @Override
    protected int[] size(MinecraftClient mc) {
        stacks.clear();
        if (mc.player == null) return null;
        for (int i = 3; i >= 0; i--) {
            ItemStack s = mc.player.getInventory().armor.get(i);
            if (!s.isEmpty()) stacks.add(s);
        }
        if (stacks.isEmpty()) return null;
        return new int[]{52, stacks.size() * 18 + 2};
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc) {
        if (background.getValue()) ctx.fill(0, 0, 52, stacks.size() * 18 + 2, bgColor());
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack s = stacks.get(i);
            ctx.drawItem(s, 2, 1 + i * 18);
            if (s.isDamageable()) {
                int max = s.getMaxDamage();
                int pct = max <= 0 ? 100 : 100 * (max - s.getDamage()) / max;
                int color = pct > 50 ? 0xFF55FF55 : pct > 25 ? 0xFFFFD83A : 0xFFFF5555;
                ctx.drawText(mc.textRenderer, pct + "%", 22, 5 + i * 18, color, true);
            }
        }
    }
}
