package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

public class PingModule extends TextHudModule {
    public PingModule() {
        super("ping", "Ping", "Shows server latency (N/A in singleplayer).", 1, 8);
    }

    @Override
    protected String[] lines(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null || mc.isInSingleplayer())
            return new String[]{"Ping: N/A"};
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return new String[]{e == null ? "Ping: N/A" : "Ping: " + e.getLatency() + " ms"};
    }
}
