package com.pikachuclient.module.hud;

import com.pikachuclient.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class ClockModule extends TextHudModule {
    private final ModeSetting format = add(new ModeSetting("Format", "24h", "24h", "12h"));
    private static final DateTimeFormatter F24 = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ENGLISH);
    private static final DateTimeFormatter F12 = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.ENGLISH);

    public ClockModule() {
        super("clock", "Clock", "Shows your real local time.", 99, 1);
    }

    @Override
    protected String[] lines(MinecraftClient mc) {
        return new String[]{LocalTime.now().format("12h".equals(format.getValue()) ? F12 : F24)};
    }
}
