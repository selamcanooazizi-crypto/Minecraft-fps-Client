package com.pikachuclient.module.hud;

import com.pikachuclient.module.setting.BooleanSetting;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** Counts real mouse clicks by polling GLFW button state every frame. */
public class CpsModule extends TextHudModule {
    private final BooleanSetting showRight = add(new BooleanSetting("Show right click", true));
    private final ArrayDeque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
    private boolean lDown, rDown;

    public CpsModule() {
        super("cps", "CPS", "Shows clicks per second for left and right mouse buttons.", 1, 15);
        enabled = true;
    }

    @Override
    protected String[] lines(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        long handle = mc.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (mc.currentScreen == null) {
            if (l && !lDown) left.add(now);
            if (r && !rDown) right.add(now);
        }
        lDown = l; rDown = r;
        while (!left.isEmpty() && now - left.peekFirst() > 1000) left.pollFirst();
        while (!right.isEmpty() && now - right.peekFirst() > 1000) right.pollFirst();
        return new String[]{showRight.getValue() ? "CPS: " + left.size() + " | " + right.size() : "CPS: " + left.size()};
    }
}
