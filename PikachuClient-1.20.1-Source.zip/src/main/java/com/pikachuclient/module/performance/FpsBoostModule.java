package com.pikachuclient.module.performance;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;

import java.util.Objects;

/**
 * Applies lighter vanilla video options while enabled and restores your original values when disabled.
 * Each option can be switched individually. Client-side only.
 */
public class FpsBoostModule extends Module {
    private final BooleanSetting particles = add(new BooleanSetting("Minimal particles", true));
    private final BooleanSetting clouds = add(new BooleanSetting("Clouds off", true));
    private final BooleanSetting shadows = add(new BooleanSetting("Entity shadows off", true));
    private final BooleanSetting fast = add(new BooleanSetting("Fast graphics", true));
    private final BooleanSetting biome = add(new BooleanSetting("No biome blend", true));
    private final BooleanSetting bobbing = add(new BooleanSetting("No view bobbing", false));
    private final BooleanSetting limitDist = add(new BooleanSetting("Limit render distance", false));
    private final NumberSetting maxDist = add(new NumberSetting("Max render distance", 10, 2, 32, 1, true));

    private ParticlesMode oParticles;
    private CloudRenderMode oClouds;
    private GraphicsMode oGraphics;
    private boolean oShadows, oBobbing;
    private int oBiome, oDist;
    private int lastSig = Integer.MIN_VALUE;

    public FpsBoostModule() {
        super("fpsboost", "FPS Boost", Category.MISC, "Lighter video options for more FPS; your original options are restored when disabled.");
    }

    private static <T> void put(SimpleOption<T> opt, T value) {
        if (!Objects.equals(opt.getValue(), value)) opt.setValue(value);
    }

    private int signature() {
        return Objects.hash(particles.getValue(), clouds.getValue(), shadows.getValue(), fast.getValue(),
                biome.getValue(), bobbing.getValue(), limitDist.getValue(), maxDist.intValue());
    }

    @Override
    protected void onEnable() {
        GameOptions o = MinecraftClient.getInstance().options;
        oParticles = o.getParticles().getValue();
        oClouds = o.getCloudRenderMode().getValue();
        oGraphics = o.getGraphicsMode().getValue();
        oShadows = o.getEntityShadows().getValue();
        oBobbing = o.getBobView().getValue();
        oBiome = o.getBiomeBlendRadius().getValue();
        oDist = o.getViewDistance().getValue();
        apply(o);
    }

    @Override
    protected void onDisable() {
        GameOptions o = MinecraftClient.getInstance().options;
        put(o.getParticles(), oParticles);
        put(o.getCloudRenderMode(), oClouds);
        put(o.getGraphicsMode(), oGraphics);
        put(o.getEntityShadows(), oShadows);
        put(o.getBobView(), oBobbing);
        put(o.getBiomeBlendRadius(), oBiome);
        put(o.getViewDistance(), oDist);
        lastSig = Integer.MIN_VALUE;
    }

    @Override
    protected void onTick(MinecraftClient mc) {
        if (signature() != lastSig) apply(mc.options);
    }

    private void apply(GameOptions o) {
        put(o.getParticles(), particles.getValue() ? ParticlesMode.MINIMAL : oParticles);
        put(o.getCloudRenderMode(), clouds.getValue() ? CloudRenderMode.OFF : oClouds);
        put(o.getEntityShadows(), shadows.getValue() ? Boolean.FALSE : Boolean.valueOf(oShadows));
        put(o.getGraphicsMode(), fast.getValue() ? GraphicsMode.FAST : oGraphics);
        put(o.getBiomeBlendRadius(), biome.getValue() ? Integer.valueOf(0) : Integer.valueOf(oBiome));
        put(o.getBobView(), bobbing.getValue() ? Boolean.FALSE : Boolean.valueOf(oBobbing));
        int dist = limitDist.getValue() ? Math.min(oDist, maxDist.intValue()) : oDist;
        put(o.getViewDistance(), dist);
        lastSig = signature();
    }
}
