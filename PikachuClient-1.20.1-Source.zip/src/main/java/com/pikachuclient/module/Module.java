package com.pikachuclient.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    private final String id, name, description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    protected boolean enabled;
    private int key = -1;
    boolean keyHeld;

    protected Module(String id, String name, Category category, String description) {
        this.id = id; this.name = name; this.category = category; this.description = description;
    }

    protected <S extends Setting<?>> S add(S setting) { settings.add(setting); return setting; }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public List<Setting<?>> getSettings() { return Collections.unmodifiableList(settings); }
    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick(MinecraftClient mc) {}

    public void toggle() { setEnabled(!enabled, true); }
    public void setEnabled(boolean value) { setEnabled(value, true); }

    public void setEnabled(boolean value, boolean notify) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            PikachuClient.LOGGER.error("Module '{}' failed during enable/disable", id, t);
            enabled = false;
        }
        if (notify) PikachuClient.notifications().push(name + (enabled ? " enabled" : " disabled"));
    }

    /** Used by the config loader: sets the saved state without running lifecycle hooks (they run on the first tick). */
    public void loadEnabledRaw(boolean value) { this.enabled = value; }

    final void startIfEnabled() {
        if (!enabled) return;
        try { onEnable(); } catch (Throwable t) {
            PikachuClient.LOGGER.error("Module '{}' failed to start", id, t);
            enabled = false;
        }
    }

    final void tickSafe(MinecraftClient mc) {
        try { onTick(mc); } catch (Throwable t) {
            PikachuClient.LOGGER.error("Module '{}' tick failed, disabling", id, t);
            setEnabled(false, false);
        }
    }

    final void stopIfEnabled() {
        if (!enabled) return;
        try { onDisable(); } catch (Throwable t) { PikachuClient.LOGGER.error("Module '{}' failed to stop", id, t); }
    }

    public void resetSettings() { for (Setting<?> s : settings) s.reset(); }

    public JsonObject saveSettings(boolean hud) {
        JsonObject o = new JsonObject();
        for (Setting<?> s : settings) if (s.isHud() == hud) o.add(s.getName(), s.toJson());
        return o;
    }

    public void loadSettings(JsonObject o, boolean hud) {
        for (Setting<?> s : settings) {
            if (s.isHud() != hud || !o.has(s.getName())) continue;
            try {
                JsonElement e = o.get(s.getName());
                s.fromJson(e);
            } catch (Exception ex) {
                PikachuClient.LOGGER.warn("Invalid value for {}.{}, using default", id, s.getName());
                s.reset();
            }
        }
    }
}
