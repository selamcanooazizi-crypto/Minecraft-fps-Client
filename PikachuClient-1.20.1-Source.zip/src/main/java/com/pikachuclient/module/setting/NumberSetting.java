package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
    private final double min, max, step;
    private final boolean integer;

    public NumberSetting(String name, double def, double min, double max, double step, boolean integer) {
        super(name, def);
        this.min = min; this.max = max; this.step = step; this.integer = integer;
        this.value = clamp(def);
    }

    private double clamp(double v) {
        double r = Math.round((v - min) / step) * step + min;
        r = Math.max(min, Math.min(max, r));
        if (integer) r = Math.round(r);
        return Math.round(r * 10000.0) / 10000.0;
    }

    @Override public void setValue(Double v) {
        if (v == null || v.isNaN() || v.isInfinite()) return;
        super.setValue(clamp(v));
    }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public boolean isInteger() { return integer; }
    public int intValue() { return (int) Math.round(value); }
    public float floatValue() { return value.floatValue(); }
    public double fraction() { return (value - min) / (max - min); }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) setValue(e.getAsDouble());
    }
}
