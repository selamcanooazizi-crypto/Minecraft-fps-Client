package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;

public abstract class Setting<T> {
    private final String name;
    private final T defaultValue;
    protected T value;
    private boolean hud;

    protected Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() { return name; }
    public T getValue() { return value; }
    public void setValue(T v) { this.value = v; }
    public void reset() { setValue(defaultValue); }
    public boolean isHud() { return hud; }
    public void markHud() { this.hud = true; }

    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement element);
}
