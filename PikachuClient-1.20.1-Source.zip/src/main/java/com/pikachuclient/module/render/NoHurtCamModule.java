package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;

/** Client-side visual: removes the camera shake when you take damage. */
public class NoHurtCamModule extends Module {
    public static NoHurtCamModule instance;

    public NoHurtCamModule() {
        super("nohurtcam", "No Hurt Cam", Category.RENDER, "Removes the camera tilt/shake when you get hurt (visual only).");
        instance = this;
    }
}
