package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.ModeSetting;
import com.pikachuclient.module.setting.NumberSetting;
import com.pikachuclient.render.ColorUtil;
import com.pikachuclient.render.LineRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.shape.VoxelShape;

/** Client-side visual: custom colour for the block outline you are looking at. */
public class BlockOverlayModule extends Module {
    public static BlockOverlayModule instance;
    private final ModeSetting color = add(new ModeSetting("Color", "Yellow", ColorUtil.NAMES));
    private final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 10, true));

    public BlockOverlayModule() {
        super("blockoverlay", "Block Overlay", Category.RENDER, "Custom colour for the targeted block outline (visual only).");
        instance = this;
    }

    /** @return true to let vanilla draw its outline, false if we drew ours. */
    public static boolean onOutline(WorldRenderContext ctx, WorldRenderContext.BlockOutlineContext oc) {
        BlockOverlayModule m = instance;
        if (m == null || !m.isEnabled()) return true;
        MinecraftClient mc = MinecraftClient.getInstance();
        VertexConsumerProvider vcp = ctx.consumers();
        if (mc.world == null || vcp == null) return true;

        VoxelShape shape = oc.blockState().getOutlineShape(mc.world, oc.blockPos(), ShapeContext.of(oc.entity()));
        float[] c = ColorUtil.rgba(m.color.getValue(), m.opacity.intValue() / 100f, 0f);
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        MatrixStack.Entry e = ctx.matrixStack().peek();
        final double ox = oc.blockPos().getX() - oc.cameraX();
        final double oy = oc.blockPos().getY() - oc.cameraY();
        final double oz = oc.blockPos().getZ() - oc.cameraZ();
        shape.forEachBox((x1, y1, z1, x2, y2, z2) ->
                LineRenderer.box(vc, e, (float) (x1 + ox), (float) (y1 + oy), (float) (z1 + oz),
                        (float) (x2 + ox), (float) (y2 + oy), (float) (z2 + oz), c));
        return false;
    }
}
