package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.ModeSetting;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;

/** Client-side visual: changes how items look in YOUR first-person hand (scale/position). */
public class ViewModelModule extends Module {
    public static ViewModelModule instance;
    /** Set by the mixin so push/pop stay balanced. */
    public static boolean pushed;

    private final ModeSetting hands = add(new ModeSetting("Hands", "Both", "Both", "Main hand", "Off hand"));
    private final NumberSetting scaleX = add(new NumberSetting("Scale X", 1.0, 0.1, 2.0, 0.05, false));
    private final NumberSetting scaleY = add(new NumberSetting("Scale Y (flat)", 1.0, 0.1, 2.0, 0.05, false));
    private final NumberSetting scaleZ = add(new NumberSetting("Scale Z", 1.0, 0.1, 2.0, 0.05, false));
    private final NumberSetting posX = add(new NumberSetting("Position X", 0.0, -1.0, 1.0, 0.05, false));
    private final NumberSetting posY = add(new NumberSetting("Position Y", 0.0, -1.0, 1.0, 0.05, false));
    private final NumberSetting posZ = add(new NumberSetting("Position Z", 0.0, -1.0, 1.0, 0.05, false));

    public ViewModelModule() {
        super("viewmodel", "View Model", Category.RENDER, "Resize/move items in your first-person hand (visual only).");
        instance = this;
    }

    public boolean appliesTo(Hand hand) {
        String h = hands.getValue();
        return h.equals("Both") || (h.equals("Main hand") && hand == Hand.MAIN_HAND) || (h.equals("Off hand") && hand == Hand.OFF_HAND);
    }

    public void apply(MatrixStack m, Hand hand, PlayerEntity player) {
        m.translate(posX.getValue(), posY.getValue(), posZ.getValue());
        boolean right = (hand == Hand.MAIN_HAND) == (player.getMainArm() == Arm.RIGHT);
        double px = right ? 0.56 : -0.56, py = -0.52, pz = -0.72;
        m.translate(px, py, pz);
        m.scale(scaleX.floatValue(), scaleY.floatValue(), scaleZ.floatValue());
        m.translate(-px, -py, -pz);
    }
}
