package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.ModeSetting;
import com.pikachuclient.module.setting.NumberSetting;
import com.pikachuclient.render.ColorUtil;
import com.pikachuclient.render.LineRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/** Cosmetic: draws a cone-shaped hat above your own head in third person. Only you see it (client-side). */
public class ChinaHatModule extends Module {
    public static ChinaHatModule instance;
    private final ModeSetting color = add(new ModeSetting("Color", "Yellow", ColorUtil.NAMES));
    private final NumberSetting radius = add(new NumberSetting("Radius", 0.55, 0.3, 1.0, 0.05, false));
    private final NumberSetting height = add(new NumberSetting("Height", 0.3, 0.1, 0.6, 0.05, false));
    private final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 10, true));

    private static final int SEGMENTS = 32;

    public ChinaHatModule() {
        super("chinahat", "China Hat", Category.RENDER, "Cosmetic cone hat above your head in third person (only you see it).");
        instance = this;
    }

    public static void render(WorldRenderContext ctx) {
        ChinaHatModule m = instance;
        if (m == null || !m.isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.getPerspective().isFirstPerson()) return;
        VertexConsumerProvider vcp = ctx.consumers();
        if (vcp == null) return;

        Vec3d cam = ctx.camera().getPos();
        Vec3d p = mc.player.getLerpedPos(ctx.tickDelta());
        float cx = (float) (p.x - cam.x);
        float baseY = (float) (p.y - cam.y) + mc.player.getHeight() - 0.12f;
        float cz = (float) (p.z - cam.z);
        float apexY = baseY + m.height.floatValue();
        float r = m.radius.floatValue();
        float a = m.opacity.intValue() / 100f;

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        MatrixStack.Entry e = ctx.matrixStack().peek();
        for (int i = 0; i < SEGMENTS; i++) {
            double a1 = 2 * Math.PI * i / SEGMENTS, a2 = 2 * Math.PI * (i + 1) / SEGMENTS;
            float[] c = ColorUtil.rgba(m.color.getValue(), a, i / (float) SEGMENTS);
            float x1 = cx + (float) Math.cos(a1) * r, z1 = cz + (float) Math.sin(a1) * r;
            float x2 = cx + (float) Math.cos(a2) * r, z2 = cz + (float) Math.sin(a2) * r;
            LineRenderer.line(vc, e, x1, baseY, z1, x2, baseY, z2, c);
            if (i % 2 == 0) LineRenderer.line(vc, e, x1, baseY, z1, cx, apexY, cz, c);
        }
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getLines());
    }
}
