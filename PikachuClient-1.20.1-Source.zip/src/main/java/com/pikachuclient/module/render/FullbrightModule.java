package com.pikachuclient.module.render;

import com.pikachuclient.mixin.SimpleOptionAccessor;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;

/** Client-side visual only: raises the gamma setting. Does not change anything on the server. */
public class FullbrightModule extends Module {
    private final NumberSetting gamma = add(new NumberSetting("Brightness", 12, 2, 15, 1, true));
    private double original = 1.0;

    public FullbrightModule() {
        super("fullbright", "Fullbright", Category.RENDER, "Client-side brightness boost (visual only).");
    }

    private static void set(MinecraftClient mc, double v) {
        @SuppressWarnings("unchecked")
        SimpleOptionAccessor<Double> acc = (SimpleOptionAccessor<Double>) (Object) mc.options.getGamma();
        acc.pikachu$setValue(v);
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        double cur = mc.options.getGamma().getValue();
        original = cur > 1.0 ? 1.0 : cur;
        set(mc, gamma.getValue());
    }

    @Override
    protected void onDisable() {
        set(MinecraftClient.getInstance(), original);
    }

    @Override
    protected void onTick(MinecraftClient mc) {
        if (mc.options.getGamma().getValue() != gamma.getValue()) set(mc, gamma.getValue());
    }
}
