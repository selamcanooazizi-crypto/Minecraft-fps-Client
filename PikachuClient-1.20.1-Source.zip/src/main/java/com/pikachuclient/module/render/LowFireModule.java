package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.NumberSetting;

/** Client-side visual: lowers or hides the first-person fire overlay. */
public class LowFireModule extends Module {
    public static LowFireModule instance;
    public final NumberSetting lowerBy = add(new NumberSetting("Lower by", 0.3, 0.0, 0.6, 0.05, false));
    public final BooleanSetting hide = add(new BooleanSetting("Hide completely", false));

    public LowFireModule() {
        super("lowfire", "Low Fire", Category.RENDER, "Lowers (or hides) the fire overlay on your screen (visual only).");
        instance = this;
    }
}
