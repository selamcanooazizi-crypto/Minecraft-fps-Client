package com.pikachuclient.module;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), HUD("HUD"),
    PLAYER("Player"), WORLD("World"), MISC("Misc"), SETTINGS("Settings");

    private final String label;
    Category(String label) { this.label = label; }
    public String getLabel() { return label; }
}
